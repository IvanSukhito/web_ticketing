<?php $__env->startSection('content'); ?>
<nav aria-label="breadcrumb">
                    <ol class="breadcrumb bg-transparent mb-0 pb-0 pt-1 px-0 me-sm-6 me-5">
                        <li class="breadcrumb-item text-sm"><a class="opacity-5 text-dark"
                                href="javascript:;">Admin</a></li>
                        <li class="breadcrumb-item text-sm text-dark active" aria-current="page">Banner</li>

                    </ol>
                   
</nav>
    <div class="row">
        <div class="col-12">
            <div class="card mb-4">
                <div class="card-header pb-0">
                    <h6>Banner</h6>
                    <a href="<?php echo e(route('admin.banners.create')); ?>" class="btn btn-primary float-end">Tambah Banner</a>
                </div>
                <div class="card-body px-0 pt-0 pb-2">
                    <div class="table-responsive p-0">
                        <table class="table align-items-center mb-0">
                            <thead>
                                <tr>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">ID</th>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Name</th>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Prioritas</th>
                                    <th class="text-secondary opacity-7">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $getBanner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dataBanner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($dataBanner->id); ?></td>
                                        <td><?php echo e($dataBanner->name); ?></td>
                                        <td><?php echo e($dataBanner->prioritas == 1 ? 'First Slide' : 'secondary'); ?></td>
                                        <td>
                                            
                                            <div class="d-flex">
                                                
                                                <?php if($dataBanner->prioritas == 1): ?>
                                                <a href="<?php echo e(route('admin.banners.updatePriority', $dataBanner->id)); ?>"
                                                    class="btn btn-primary me-2">Priority</a>
                                                <?php else: ?>
                                                <a href="<?php echo e(route('admin.banners.updatePriority', $dataBanner->id)); ?>"
                                                class="btn btn-info me-2">Set Priority</a>
                                                <?php endif; ?>
                                                
                                                <a href="<?php echo e(route('admin.banners.edit', $dataBanner->id)); ?>"
                                                    class="btn btn-warning me-2">Edit</a>
                                                
                                                <form onsubmit="return confirm('Hapus Kategori <?php echo e($dataBanner->name); ?>?')"
                                                    action="<?php echo e(route('admin.banners.destroy', $dataBanner->id)); ?>" method="POST">
                                                    <?php echo method_field('DELETE'); ?>
                                                    <?php echo csrf_field(); ?>
                                                    <button type="submit" class="btn btn-danger">Delete</button>

                                                </form>

                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\web_ticketing\resources\views/admin/Banner/index.blade.php ENDPATH**/ ?>