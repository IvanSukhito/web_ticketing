<?php $__env->startSection('content'); ?>
<section class="hero">
        <img class= "background" src="<?php echo e(asset('img/auth/Background.png')); ?>" alt="background">
        <form method="POST" action="<?php echo e(route('login')); ?>">
        <?php echo csrf_field(); ?>
        <div class="content">
            <h1><?php echo e(__('Login')); ?></h1>
            <div class="input-1">
                <label for="email" ><?php echo e(__('Email Address')); ?></label>
               
                <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>
               
            </div>
            <div class="input-1">
                <label for="password" ><?php echo e(__('password')); ?></label>
             
                    <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" value="<?php echo e(old('password')); ?>" required autocomplete="password" autofocus>
                
            </div>
      
            <div class="cta">
                <button class="pill">Log In</button>
                <div class="or">
                    <hr />
                    <p>atau masuk dengan</p>
                    <hr />
                </div>
                <a href="<?php echo e(route('google-auth')); ?>"  class="button pill2">
                <div class="button-google">
                    <img src="<?php echo e(asset('img/auth/google.png')); ?>" alt="google"> 
                    <div style="vertical-align: middle;"> Google</div>
                   
                </div>
                </a>
                <p>Belum memiliki akun Ticoz? <a href="<?php echo e(route('register')); ?>" id="login">&nbsp;Daftar</a></p>
            </div>
        </div>
        </form>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\web_ticketing\resources\views/auth/login.blade.php ENDPATH**/ ?>