<?php $__env->startSection('content'); ?>


    <section class="hero">

        
        <?php $__currentLoopData = $acaras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $acara): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route('detail', $acara->slug)); ?>">
                <!-- <img src="<?php echo e($acara->thumbnail); ?>" alt="<?php echo e($acara->name); ?>"> -->
                <div class="card-container">
                    <div class="card-image"><img src="<?php echo e($acara->thumbnail); ?>" alt="<?php echo e($acara->name); ?>" class="card-image">
                    </div>
                    <div class="card-detail">
                        <h3><?php echo e($acara->name); ?></h3>
                        <p><?php echo e($acara->description); ?></p>
                        <span>Mulai dari Rp <?php echo e(number_format($acara->start_from)); ?></span>
                    </div>
                </div>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



    </section>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script-bottom'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('script-bottom'); ?>
    <script type="text/javascript">
        $(document).ready(function() {
            $("#category").select2();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.homeUser', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\web_ticketing\resources\views/frontend/search.blade.php ENDPATH**/ ?>