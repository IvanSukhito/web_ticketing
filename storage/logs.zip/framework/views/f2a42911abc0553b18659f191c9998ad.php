<?php $__env->startSection('content'); ?>


    <section class="hero">
        
       
           

        <div class="container">
        <?php $__empty_1 = true; $__currentLoopData = $acaras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $acara): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <a href="<?php echo e(route('detail', $acara->slug)); ?>" style="text-decoration:none">
                <div class="card m-2" style="width: 18rem;">
                    <img src="<?php echo e($acara->thumbnail); ?>" class="card-img-top custom-card-img" alt="...">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($acara->name); ?></h5>
                        <p class="card-text"><?php echo e($acara->lokasi); ?></p>
                        <span>Mulai dari Rp <?php echo e(number_format($acara->start_from)); ?></span>

                    </div>
                </div>
                </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p>Acara Tidak ada</p>
                <?php endif; ?>
        </div>

            

       


    </section>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script-bottom'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('script-bottom'); ?>
    <script type="text/javascript">
        $(document).ready(function() {
            $("#category").select2();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.homeUser', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\web_ticketing\resources\views/frontend/category.blade.php ENDPATH**/ ?>