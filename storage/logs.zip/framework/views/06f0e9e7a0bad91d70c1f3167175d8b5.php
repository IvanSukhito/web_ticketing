<?php $__env->startSection('content'); ?>
    <main class="container" style="padding-top:20px;">
    <div class="p-4 p-md-5 mb-4 text-white rounded bg-dark" style="position: relative; width: 100%; height: 100%; overflow: hidden;">
    <div class="col-md-6 px-0" style="position: relative; width: 100%; height: 100%;">
        <?php if(isset($acara->image_content)): ?>
        <img src="<?php echo e(Storage::url($acara->image_content)); ?>" alt="" style="width: 100%; object-fit: cover;">
        <?php else: ?>
        <img src="<?php echo e(Storage::url('acaras/image_content/no-image.png')); ?>" alt="" style="width: 100%; object-fit: cover;">
        <?php endif; ?>
    </div>
</div>





        <div class="row g-5">
            <div class="col-md-8">
                <h3 class="pb-4 mb-4 fst-italic border-bottom">
                    <?php echo e($acara->name); ?>

                </h3>

                <article class="blog-post">
                    <h2 class="blog-post-title">Description Events</h2>
                    <?php if(isset($acara->category) && isset($acara->category->name)): ?>
                          <p class="blog-post-meta"><b>Acara : </b> <?php echo e($acara->category->name); ?> - <?php echo e($acara->waktu->format('d-m-Y')); ?> </p>
                    <?php else: ?>
                        
                    <?php endif; ?>

                  

                    <p><?php echo e($acara->description); ?></p>
                    <hr>
                    <p><b>Location Map : </b><?php echo e($acara->lokasi); ?></p>
                    <?php if(isset($acara->lokasi) || isset($acara->longitude)): ?>
                    <div id="directMap">
                          
                    </div>
                    <?php else: ?>
                    <p>Map Not available</p>
                    <?php endif; ?>

                   
                </article>

                <article class="blog-post">
                    <h3>Slot Terdaftar</h3>
                    <p>And don't forget about tables in these posts:</p>
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Upvotes</th>
                                <th>Downvotes</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>Alice</td>
                                <td>10</td>
                                <td>11</td>
                            </tr>
                            <tr>
                                <td>Bob</td>
                                <td>4</td>
                                <td>3</td>
                            </tr>
                            <tr>
                                <td>Charlie</td>
                                <td>7</td>
                                <td>9</td>
                            </tr>
                        </tbody>
                        <tfoot>
                            <tr>
                                <td>Totals</td>
                                <td>21</td>
                                <td>23</td>
                            </tr>
                        </tfoot>
                    </table>

                    <p>This is some additional paragraph placeholder content. It's a slightly shorter version of the other
                        highly repetitive body text used throughout.</p>
                </article>

               
            </div>

            <div class="col-md-4">
                <div class="position-sticky" style="top: 2rem;">
                    <div class="custom-card">
                        <h5 class="checkout-out">Check Out</h5>
                        <hr>
                        <div class="d-flex justify-content-between align-items-center">
                            <div>

                                <p class="custom-card-title ">
                                    <?php if($acara->ticket): ?>
                                        <?php echo e($acara->ticket->name); ?>

                                    <?php else: ?>
                                        Tiket tidak tersedia
                                    <?php endif; ?>
                                </p>
                                <p class="custom-card-price ">
                                    <?php if($acara->ticket): ?>
                                        
                                        <p style="color:red; font-weight:bold;">Rp <?php echo e(number_format($acara->ticket->harga, 0, ',', '.') ?? 'Tiket tidak tersedia'); ?>

                                    <?php else: ?>
                                        <p style="color:red;">Harga tidak tersedia</p>
                                    <?php endif; ?>
                                </p>

                            </div>
                        </div>
                        <?php if($acara->ticket): ?>
                        
                        <a href="<?php echo e(route('checkout', $acara->slug)); ?>" class="btn btn-primary ">Buy
                            Ticket</a>
                        
                        <?php else: ?>
                                       
                        <?php endif; ?>
                     
                    </div>
                    <!-- isi nanti kalo ada bisa banyak tiket -->
                </div>

            </div>
        </div>

        <div class="row mb-2">
            <?php $__currentLoopData = $getRecomendAcara; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rekomendasi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-6">
                <div class="row g-0 border rounded overflow-hidden flex-md-row mb-4 shadow-sm h-md-250 position-relative">
                    <div class="col p-4 d-flex flex-column position-static">
                   
                        <?php if(isset($rekomendasi->category->name)): ?>
                        <strong class="d-inline-block mb-2 text-primary"><?php echo e($rekomendasi->category->name); ?></strong>
                        <?php else: ?>
                        <strong class="d-inline-block mb-2 text-primary">No Category</strong>
                        <?php endif; ?>
                        <h3 class="mb-0"><?php echo e($rekomendasi->name); ?></h3>
                        <div class="mb-1 text-muted"><?php echo e(date('d-M-Y', strtotime($rekomendasi->waktu))); ?></div>
                        <p class="card-text mb-auto">This is a event from lapaktiket.com </p>
                        <a href="<?php echo e(route('detail', $rekomendasi->slug)); ?>" class="stretched-link">Continue reading</a>
                    </div>
                    <div class="col-auto d-none d-lg-block">
                    <svg class="bd-placeholder-img" width="200" height="250" xmlns="http://www.w3.org/2000/svg"
                         role="img" aria-label="Placeholder: Thumbnail" preserveAspectRatio="xMidYMid slice"
                         focusable="false">
                        <title>Placeholder</title>
                        <rect width="100%" height="100%" fill="#55595c"></rect>
                        <image x="0" y="0" width="100%" height="100%" xlink:href="<?php echo e($rekomendasi->thumbnail); ?>" />
                       
                    </svg>


                    </div>
                </div>
            </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         
           
        </div>

    </main>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script-bottom'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('script-bottom'); ?>
    <script type="text/javascript">
         let dataLokasi = "<?= $acara->lokasi ?>";
         let dataLatitude = "<?= $acara->latitude ?>";
         let dataLongitude = "<?= $acara->longitude ?>";
         console.log(dataLongitude);
         $(document).ready(function() {

            var lokasiStr = dataLokasi.replace(/\s+/g, '+').toLowerCase();
           
                    if(!dataLatitude && !dataLongitude){

                         console.log('lokasi aja');
                         hanyaLokasi();
                          // kalo ga ada timpa iframe map pake input lokasi aja

                     }else{
                         console.log('ada latitude');
                         adaLongLat();
                     // timpa iframe map pake longitude sama laitude aja
                     }
                function hanyaLokasi(){

                    let html = '<iframe width="100%" height="600" src="https://maps.google.com/maps?width=100%&amp;height=600&amp;hl=en&amp;q='+lokasiStr+'&amp;ie=UTF8&amp;t=&amp;z=14&amp;iwloc=B&amp;output=embed" frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe><br />';
                    
                    $('#directMap').html(html);
                    
                    return false;
                }
                function adaLongLat(){
                
                    let html = '<iframe width="100%" height="600" src="https://maps.google.com/maps?width=100%&amp;height=600&amp;hl=en&amp;coord='+dataLatitude+','+dataLongitude+'&amp;q='+lokasiStr+'&amp;ie=UTF8&amp;t=&amp;z=14&amp;iwloc=B&amp;output=embed" frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe><br />';
                    
                    $('#directMap').html(html);
                    
                    return false;
                }
         });

        console.log(dataLokasi);
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.homeUser', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\web_ticketing\resources\views/frontend/details.blade.php ENDPATH**/ ?>