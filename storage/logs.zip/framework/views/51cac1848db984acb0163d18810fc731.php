<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-12">
            <div class="card mb-4">
                <div class="card-header pb-0">
                    <h6>Add Acara</h6>
                </div>
                <div class="card-body px-2 pt-0 pb-2">
                    <?php if($errors->any()): ?>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <strong style="color:white;"    >Failed!</strong> <?php echo e($error); ?>

                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    <form action = "<?php echo e(route('admin.vendor-client.store')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="name">Nama Vendor</label>
                            <input name ="name"type="text" class="form-control" id="exampleInputName" aria-describedby="name" placeholder="Vendor's Name">
                        </div>
                        <div class="form-group">
                            <label for="name">Role</label>
                            <input name ="role" type="text" class="form-control" id="exampleInputConfirmPassword" value="vendor" readonly>
                        </div>
                        <div class="form-group">
                            <label for="name">No Telephone</label>
                            <input name ="no_telp" type="text" class="form-control" id="exampleInputConfirmPhone" aria-describedby="Phone" placeholder="0813 1494 5143">
                        </div>
                        <div class="form-group">
                            <label for="name">NIK</label>
                            <input name ="nik" type="text" class="form-control" id="exampleInputConfirmPassword" aria-describedby="NIK" placeholder="3173 0128 0304 1040">
                        </div>
                        <div class="form-group">
                            <label for="name">Email Vendor</label>
                            <input name ="email"type="email" class="form-control" id="exampleInputEmail" aria-describedby="email" placeholder="Vendor@mail.com">
                        </div>
                        <div class="form-group">
                            <label for="name">Password</label>
                            <input name ="password" type="password" class="form-control" id="exampleInputPassword" aria-describedby="Password" placeholder="Password123">
                        </div>
                        <div class="form-group">
                            <label for="name">Confirm Password</label>
                            <input name ="password_confirmation" type="password" class="form-control" id="exampleInputConfirmPassword" aria-describedby="Password" placeholder="Password123">
                        </div>
                        <button type="submit" class="btn btn-primary">Submit</button>

                    </form>
                </div>
                
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script-bottom'); ?>
 
    <script type="text/javascript">
        $(document).ready(function() {
            $("#category").select2();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\web_ticketing\resources\views/admin/Vendor-Client/create.blade.php ENDPATH**/ ?>