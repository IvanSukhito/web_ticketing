<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-12">
            <div class="card mb-4">
                <div class="card-header pb-0">
                    <h6>Add Banner</h6>
                </div>
                <div class="card-body px-2 pt-0 pb-2">
                    <?php if($errors->any()): ?>
                        <div class ="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    <form action = "<?php echo e(route('admin.banners.store')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="name">Nama Banner</label>
                            <input name ="name"type="text" class="form-control" id="exampleInputEmail1"
                                aria-describedby="emailHelp" placeholder="Music">
                        </div>
                        <div class="form-group">
                            <label for="p">Image banner</label>
                            <input name ="img" type="file" accept="image/png, image/gif, image/jpeg"
                                class="form-control" multiple id="p" aria-describedby="emailHelp"
                                placeholder="Enter Height">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Status</label>
                            <select id="category" class="form-control" name="status">
                          
                                    <option value="active"><?php echo app('translator')->get('active'); ?></option>
                                    <option value="unactive"><?php echo app('translator')->get('unactive'); ?></option>
                            </select>
                        </div>


                        <button type="submit" class="btn btn-primary">Submit</button>

                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script-bottom'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('script-bottom'); ?>
    <script type="text/javascript">
        $(document).ready(function() {
            $("#category").select2();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\web_ticketing\resources\views/admin/Banner/create.blade.php ENDPATH**/ ?>