<?php $__env->startSection('content'); ?>


    <section class="hero">


        <div id="carouselExampleAutoplaying" class="carousel slide" data-bs-ride="carousel">
            <div class="carousel-inner">
                <?php $__empty_1 = true; $__currentLoopData = $banner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="carousel-item <?php echo e($banner->prioritas == 1 ? 'active' : ''); ?>" data-id="<?php echo e($key); ?>"
                        data-prioritas="<?php echo e($banner->prioritas); ?>">
                        <img src="<?php echo e(Storage::url($banner->img)); ?>" class="d-block w-100" alt="...">
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="carousel-item">
                        <img src="<?php echo e(asset('img/slider/2.png')); ?>" class="d-block w-100" alt="...">
                    </div>
                <?php endif; ?>
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#carouselExample" data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#carouselExample" data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button>
        </div>




        
        <div class="card1">
            <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="card-info">
                    <a href="<?php echo e(route('front.category', $category)); ?>">
                        <img src="<?php echo e(Storage::url($category->icon)); ?>" alt="card">
                        <p><?php echo e($category->name); ?></p>
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p>Category Tidak tersedia</p>
            <?php endif; ?>
        </div>


        
        <div class="container">

            <?php $__currentLoopData = $acaras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $acara): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card m-2" style="width: 18rem;">
                    <img src="<?php echo e($acara->thumbnail); ?>" class="card-img-top custom-card-img" alt="...">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($acara->name); ?></h5>
                        <p class="card-text"><?php echo e($acara->lokasi); ?></p>
                        <a href="<?php echo e(route('detail', $acara->slug)); ?>" class="btn btn-primary"><?php echo app('translator')->get('Lihat Detail'); ?></a>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="d-flex justify-content-center mt-4">
            <?php echo e($acaras->links('pagination::bootstrap-4')); ?>

        </div>


    </section>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script-bottom'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('script-bottom'); ?>
    <!-- <script src="https://maxcdn.bootstrapcdn.com/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script> -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script type="text/javascript">
        $(document).ready(function() {
            //$("#category").select2();



            $('#carouselExampleAutoplaying .carousel-control-prev, #carouselExampleAutoplaying .carousel-control-next')
                .click(function() {
                    // Temukan item aktif saat ini dan ubah prioritasnya
                    var activeItem = $('.carousel-item.active');
                    console.log(activeItem);
                    activeItem.each(function() {
                        $(this).attr('data-prioritas', 1);
                        console.log('Item aktif sekarang:', $(this).data('id'));
                    });
                });
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.homeUser', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\web_ticketing\resources\views/frontend/index.blade.php ENDPATH**/ ?>