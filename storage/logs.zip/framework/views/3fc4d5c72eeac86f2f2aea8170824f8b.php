<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card mb-4">
                <div class="card-header pb-0">
                    <h6>Acara</h6>
                    <a href="<?php echo e(route('admin.acara.create')); ?>"class="btn btn-primary float-end">Buat Acara</a>
                </div>
                <div class="card-body px-0 pt-0 pb-2">
                    <div class="table-responsive p-0">
                        <table class="table align-items-center mb-0">
                            <thead>
                                <tr>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">ID
                                    </th>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">
                                        Name </th>
                                    <th
                                        class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                        Nama Pelaksana</th>
                                    <th
                                        class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                        Waktu</th>
                                    <th
                                        class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                        Kategori</th>
                                    <th class="text-secondary opacity-7">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $acaras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $acara): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    
                                    <tr>
                                        <td><?php echo e($acara->id); ?></td>
                                        <td><?php echo e($acara->name); ?></td>
                                        <td><?php echo e($acara->namaPelaksana); ?></td>
                                        <td><?php echo e($acara->waktu->format('d M Y')); ?></td>
                                        <td><?php echo e($acara->category->name ?? '-'); ?></td>
                                        <td>
                                            
                                            <a
                                                href="<?php echo e(route('admin.acara.edit', [
                                                    'acara' => $acara->id,
                                                ])); ?>"class="btn btn-warning">Edit</a>
                                            <a
                                                href="<?php echo e(route('admin.acara.tickets.index', [
                                                    'acara' => $acara->id,
                                                ])); ?>"class="btn btn-info">Tiket</a>

                                            
                                            <form onsubmit="return confirm('Hapus Acara <?php echo e($acara->name); ?>?')"
                                                action="<?php echo e(route('admin.acara.destroy', [
                                                    'acara' => $acara->id,
                                                ])); ?>"method="POST">
                                                <?php echo method_field('DELETE'); ?>
                                                <?php echo csrf_field(); ?>
                                                <input type="submit" class="btn btn-danger" value="Delete">
                                            </form>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="d-flex justify-content-center mt-3">
                        <?php echo e($acaras->links('pagination::bootstrap-4')); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\web_ticketing\resources\views/admin/acara/index.blade.php ENDPATH**/ ?>