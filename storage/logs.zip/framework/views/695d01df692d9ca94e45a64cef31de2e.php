<?php $__env->startSection('content'); ?>
<nav aria-label="breadcrumb">
                    <ol class="breadcrumb bg-transparent mb-0 pb-0 pt-1 px-0 me-sm-6 me-5">
                        <li class="breadcrumb-item text-sm"><a class="opacity-5 text-dark"
                                href="javascript:;">Admin</a></li>
                        <li class="breadcrumb-item text-sm text-dark active" aria-current="page">Vendor</li>

                    </ol>
                   
</nav>
    <div class="row">
        <div class="col-12">
            <div class="card mb-4">
                <div class="card-header pb-0">
                    <h6>Vendor</h6>
                    <a href="<?php echo e(route('admin.vendor-client.create')); ?>" class="btn btn-primary float-end">Tambah Vendor</a>
                </div>
                <div class="card-body px-0 pt-0 pb-2">
                    <div class="table-responsive p-0">
                        <table class="table align-items-center mb-0">
                            <thead>
                                <tr>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">No</th>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Name</th>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">No Telp</th>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Email</th>
                                    <th class="text-secondary opacity-7">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $getVendor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dataVendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($dataVendor->id); ?></td>
                                        <td><?php echo e($dataVendor->name); ?></td>
                                        <td><?php echo e($dataVendor->no_telp); ?></td>
                                        <td><?php echo e($dataVendor->email); ?></td>
                                        <td>
                                            
                                            <div class="d-flex">
                                                
                                                <a href="<?php echo e(route('admin.vendor-client.edit', $dataVendor->id)); ?>"
                                                    class="btn btn-warning me-2">Edit</a>
                                                
                                                <form onsubmit="return confirm('Hapus Kategori <?php echo e($dataVendor->name); ?>?')"
                                                    action="<?php echo e(route('admin.vendor-client.destroy', $dataVendor->id)); ?>" method="POST">
                                                    <?php echo method_field('DELETE'); ?>
                                                    <?php echo csrf_field(); ?>
                                                    <button type="submit" class="btn btn-danger">Delete</button>

                                                </form>

                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
@

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\web_ticketing\resources\views/admin/Vendor-Client/index.blade.php ENDPATH**/ ?>